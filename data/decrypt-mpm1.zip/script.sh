#!/sbin/sh
sed -i 's/forceencrypt/encryptable/g' /vendor/etc/fstab.qcom